/*global React, window */

module.exports.preview = React.createClass({
    render: function () {
        return React.DOM.div({ className: "widget-mobile-features-hide-preview" });
    }
});
