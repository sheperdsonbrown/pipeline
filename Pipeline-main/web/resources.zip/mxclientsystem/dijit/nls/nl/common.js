//>>built
define("dijit/nls/nl/common",{buttonOk:"OK",buttonCancel:"Annuleren",buttonSave:"Opslaan",itemClose:"Sluiten"});
