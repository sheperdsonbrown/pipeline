//>>built
define("dijit/nls/az/common",{buttonOk:"Ok",buttonCancel:"L\u0259\u011fv et",buttonSave:"Saxla",itemClose:"Ba\u011fla"});
