//>>built
define("dijit/nls/ca/loading",{loadingState:"S'est\u00e0 carregant...",errorState:"Ens sap greu. S'ha produ\u00eft un error."});
