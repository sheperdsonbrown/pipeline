//>>built
define("dijit/_editor/nls/ko/LinkDialog",{createLinkTitle:"\ub9c1\ud06c \ud2b9\uc131",insertImageTitle:"\uc774\ubbf8\uc9c0 \ud2b9\uc131",url:"URL:",text:"\uc124\uba85:",target:"\ub300\uc0c1",set:"\uc124\uc815",currentWindow:"\ud604\uc7ac \ucc3d",parentWindow:"\uc0c1\uc704 \ucc3d",topWindow:"\ucd5c\uc0c1\uc704 \ucc3d",newWindow:"\uc0c8 \ucc3d"});
