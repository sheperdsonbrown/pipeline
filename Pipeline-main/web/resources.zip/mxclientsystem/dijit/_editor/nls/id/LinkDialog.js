//>>built
define("dijit/_editor/nls/id/LinkDialog",{createLinkTitle:"Properti Tautan",insertImageTitle:"Properti Gambar",url:"URL:",text:"Deskripsi:",target:"Target:",set:"Atur",currentWindow:"Jendela Saat Ini",parentWindow:"Jendela Induk",topWindow:"Jendela Paling Atas",newWindow:"Jendela Baru"});
