//>>built
define("dijit/form/nls/zh/Textarea",{iframeEditTitle:"\u7f16\u8f91\u533a\u57df",iframeFocusTitle:"\u7f16\u8f91\u533a\u57df\u6846"});
