//>>built
define("dijit/form/nls/zh/validate",{invalidMessage:"\u8f93\u5165\u7684\u503c\u65e0\u6548\u3002",missingMessage:"\u8be5\u503c\u662f\u5fc5\u9700\u7684\u3002",rangeMessage:"\u6b64\u503c\u8d85\u51fa\u8303\u56f4\u3002"});
