//>>built
define("dijit/form/nls/nb/Textarea",{iframeEditTitle:"redigeringsomr\u00e5de",iframeFocusTitle:"ramme for redigeringsomr\u00e5de"});
